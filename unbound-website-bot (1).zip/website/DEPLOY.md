# UNBOUND SHOP — Website Chat Bot

Telegram bot-এর মতোই AI chat bot, এখন website-এ।

## কী কী আছে

- `server.js` — Chat API server (brain + order + panel + ticket, Telegram bot-এর logic reuse করে)
- `widget.js` — Website-এ embed করার floating chat widget
- `chat.html` — Standalone chat page (widget embed না করা গেলে link হিসেবে)
- `railway.json` — Railway deploy config

## Deploy (Railway)

1. Railway-এ নতুন project → GitHub repo বা folder deploy
2. Root directory: `website/`
3. Environment variable: `TELEGRAM_BOT_TOKEN` = তোমার bot token (Limon-এর Telegram-এ order notification যাবে)
4. Deploy → public URL পাবে, যেমন `https://unbound-webbot.up.railway.app`

## Website-এ যোগ করা

### Option A: Floating widget (সব page-এ chat button)
Website-এর HTML-এ `</body>`-এর আগে বসাও:
```html
<script src="https://YOUR-URL/widget.js" data-api="https://YOUR-URL"></script>
```
`YOUR-URL` → Railway URL দিয়ে replace করো।

### Option B: শুধু link button (base44-এ custom script না চললে)
Button/Link-এর URL দাও:
```
https://YOUR-URL/
```
কাস্টমার tap করলে full chat page খুলবে।

## কীভাবে কাজ করে

- Customer website-এ chat করে → একই brain, menu, diamond, panel, order flow
- Order/payment হলে **Limon-এর Telegram-এ** notification যায় (আগের মতোই)
- Limon Telegram থেকেই ✅/❌ বাটন চাপে — website customer-কে reply যায়
- Session ID দিয়ে প্রতিটি visitor আলাদা থাকে

## Test (local)

```bash
cd website && PORT=8090 node server.js
# http://localhost:8090/ → chat page
# widget test: কোনো HTML-এ script tag বসিয়ে দেখো
```
